
def FirstFit(blockSize, x, processSize, y): 
          
# code to store the block id of the block that needs to be allocated to a process
    allocate = [-1] * y  
  
    # Any process is assigned with the memory at the initial stage 
  
    # find a suitable block for each process 
    # the blocks are allocated as per their size 
  
    
    for i in range(y): 
        for j in range(x): 
            if blockSize[j] >= processSize[i]: 
                  
                # assign the block j to p[i] process  
                allocate[i] = j  
  
                # available block memory is reduced   
                blockSize[j] = blockSize[j] - processSize[i]  
  
                break

      
    print(" Process No.  Process Size  Block No.")
 
    for i in range(y): 
    
        print(" ", i + 1, "         ", processSize[i],"          ", end = " ") 

        if allocate[i] != -1:  

            print(allocate[i] + 1)
        else: 
    
            print ("Not Allocated")



#implementation of Best - Fit algorithm  
def bestFit(blockSize, x, processSize, y): 
    
    allocation = [-1] * y  
   
    for i in range(y): 
          
        bestIdx = -1
        for j in range(x): 
            if blockSize[j] >= processSize[i]: 
                if bestIdx == -1:  
                    bestIdx = j  
                elif blockSize[bestIdx] > blockSize[j]:  
                    bestIdx = j 
  
        if bestIdx != -1: 
               
            allocation[i] = bestIdx  
  
            blockSize[bestIdx] = blockSize[bestIdx] - processSize[i] 
  
    print("Process No. Process Size     Block no.") 
    for i in range(y): 
        print(" ", i + 1, "         ", processSize[i],"          ", end = " ") 


        if allocation[i] != -1:  
            print(allocation[i] + 1)  
        else: 
            print("Not Allocated") 
  
# Driver code  
if __name__ == '__main__':
    
    blockSize = [100, 300, 200, 50, 600]  
    processSize = [90, 50, 60, 70, 4432, 400, 88]  
    x = len(blockSize)  
    y = len(processSize)  
    FirstFit(blockSize, x, processSize, y)
    
    blockSize = [100, 300, 200, 50, 600]  
    processSize = [90, 50, 60, 70, 4432, 400, 88]  
    x = len(blockSize)  
    y = len(processSize)  
    bestFit(blockSize, x, processSize, y) 

      

            
